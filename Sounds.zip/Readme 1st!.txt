+====================================================+
|           Wingnuts - Temporal Navigator            |
+====================================================+

WingNuts requires QuickTime. Windows 7/8/10 users can
install QT_Lite_410, which is included in the 'Extras'
folder.

The game is ready to go, no installation needed. Run
WingNuts.exe to play.

It's recommended to play in windowed mode if you have
a multi-screen setup, or it will mess up your desktop
layout.

Enjoy!

+====================================================+
|              Cracked by [Q] 16-8-2018              |
+====================================================+


